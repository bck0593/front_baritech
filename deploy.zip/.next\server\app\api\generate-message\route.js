(()=>{var e={};e.id=2609,e.ids=[2609],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},53279:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>m,routeModule:()=>c,serverHooks:()=>l,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>x});var s={};t.r(s),t.d(s,{POST:()=>d});var a=t(96559),n=t(48088),o=t(37719),p=t(39024),i=t(81248),u=t(32190);async function d(e){try{let{mealStatus:r,mealTime:t,mealMemo:s,excretionStatus:a,excretionTime:n,excretionMemo:o}=await e.json(),d=`
保育園での愛犬の今日の記録を基に、保護者向けの温かく親しみやすいメッセージを生成してください。

【今日の記録】
食事：
- 状態: ${r||"記録なし"}
- 時間: ${t||"記録なし"}
- メモ: ${s||"記録なし"}

排泄：
- 状態: ${a||"記録なし"}
- 時間: ${n||"記録なし"}
- メモ: ${o||"記録なし"}

【メッセージ作成のポイント】
- 保護者が安心できるような温かい表現を使用
- 愛犬の様子を具体的に伝える
- 200文字程度で簡潔に
- 敬語を使用し、丁寧な文体で
- 愛犬の名前は「○○ちゃん」として記載
    `,{text:c}=await (0,p.Df)({model:(0,i.N)("gpt-4o"),prompt:d});return u.NextResponse.json({message:c})}catch(e){return console.error("AI生成エラー:",e),u.NextResponse.json({error:"メッセージの生成に失敗しました"},{status:500})}}let c=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/generate-message/route",pathname:"/api/generate-message",filename:"route",bundlePath:"app/api/generate-message/route"},resolvedPagePath:"C:\\Users\\bck05\\Desktop\\front_0817\\app\\api\\generate-message\\route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:g,workUnitAsyncStorage:x,serverHooks:l}=c;function m(){return(0,o.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:x})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[8096],()=>t(53279));module.exports=s})();